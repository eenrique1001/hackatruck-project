//
//  tela_gastosApp.swift
//  tela_gastos
//
//  Created by Turma01-3 on 26/02/25.
//

import SwiftUI

@main
struct tela_gastosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
